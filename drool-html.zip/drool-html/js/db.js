import {
  getFirestore,
  collection,
  getDocs,
  addDoc
} from 'https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js';

const FIREBASE_CONFIG = {
  apiKey: "AIzaSyB5DL74cy7TpkogDJKkDvmtSCQ2cbGUeGE",
  authDomain: "loop-dc9be.firebaseapp.com",
  projectId: "loop-dc9be",
  storageBucket: "loop-dc9be.appspot.com",
  messagingSenderId: "1040127971614",
  appId: "1:1040127971614:web:31013a10e7d8b59fb5790f"
};

const app = initializeApp(FIREBASE_CONFIG);
const db = getFirestore(app);

let messages = [];

async function getMessages() {
  const messagesCol = collection(db, 'messages');
  const messagesSnapshot = await getDocs(messagesCol);
  const messages = messagesSnapshot.docs.map(doc => doc.data());
  return messages;
}

getMessages().then(m => {
  messages = m;
  renderMessages();
});

function renderMessages() {
  const mmm = document.querySelector('#messages');

  mmm.innerHTML = messages
    .map(message => `<p>${message.name}, ${message.email}, ${message.phone}, ${message.message}</p>`)
    .join('');
}

function setupForm() {
  const submitButton = document.querySelector('#submitButton');

  const nameField = document.querySelector('#name');
  const emailField = document.querySelector('#email');
  const phoneField = document.querySelector('#phone');
  const messageField = document.querySelector('#message');

  submitButton.addEventListener('click', async (e) => {
    e.preventDefault()
    
    await addDoc(collection(db, 'messages'), {
      name: nameField.value,
      email: emailField.value,
      phone: phoneField.value,
      message: messageField.value
    });

    messages.push({
      name: nameField.value,
      email: emailField.value,
      phone: phoneField.value,
      message: messageField.value
    });

    renderMessages();
  });
}

window.addEventListener('DOMContentLoaded', setupForm);
